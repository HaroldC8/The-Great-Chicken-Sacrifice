using LootLocker.Requests;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class Spawner : MonoBehaviour
{
    public int spawnAmount = 10;
    public int scoreForEnd = 50;
    public int curScore = 0;
    private int shownScore = 0;
    public Bounds bounds;
    public GameObject egg;
    private Vector2 mousePos;
    public LayerMask whatToKill;
    public Bounds killBounds;
    public TextMeshProUGUI scoreText, scoreText2, spawnText;
    public float countTimer = 0.1f;
    private float curTime = 0;
    public List<TextMeshProUGUI> leaderboardTexts;
    private string key = "leadkey";
    private string playerID = "";

    private void Start()
    {
        LootLockerSDKManager.StartGuestSession((response) =>
        {
            if(response.success)
            {
                playerID = response.player_id.ToString();
                ShowScores();
            }
        });
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireCube(bounds.center, bounds.size);
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(killBounds.center, killBounds.size);
    }

    private void Update()
    {
        Collider2D[] colliders2D = Physics2D.OverlapBoxAll(killBounds.center, killBounds.size, 0, whatToKill);
        foreach (var item in colliders2D)
        {
            Destroy(item.gameObject);
            curScore += scoreForEnd;
        }
        if(curScore > 0 && Time.time - curTime > countTimer/curScore)
        {
            curTime = Time.time;
            curScore--;
            shownScore++;
            scoreText.text = shownScore.ToString();
            scoreText2.text = ("Submit: "+shownScore);
        }
    }

    public void OnPoint(InputValue val)
    {
        mousePos = Camera.main.ScreenToWorldPoint(val.Get<Vector2>());
    }

    public void OnClick(InputValue val)
    {
        if(bounds.Contains(mousePos) && val.isPressed && spawnAmount > 0)
        {
            Instantiate(egg, new Vector3(mousePos.x, bounds.max.y, 0), Quaternion.identity);
            spawnAmount--;
            spawnText.text = spawnAmount.ToString();
        }
    }

    public void ShowScores()
    {
        LootLockerSDKManager.GetScoreList(key, leaderboardTexts.Count, (response) =>
        {
            if (response.success)
            {
                LootLockerLeaderboardMember[] members = response.items;
                if(response.items == null)
                {
                    return;
                }
                for (int i = 0; i < members.Length; i++)
                {
                    leaderboardTexts[i].text = (members[i].rank + ". " + members[i].score);
                }
            }
        });
    }

    public void SubmitScore()
    {
        if(playerID.Length > 0)
        {
            LootLockerSDKManager.SubmitScore(playerID, shownScore, key, (response) =>
            {
                if (response.success)
                {
                    ShowScores();
                }
            });
        }
    }
}
