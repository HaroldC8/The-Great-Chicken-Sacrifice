using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnOnBounce : MonoBehaviour
{
    public List<GameObject> spawn;
    public int scoreForPeg = 10;
    public int numOfSpawns = 1;
    public LayerMask whenToSpawn;
    public float radius;
    public bool destroy;
    public GameObject spawnedOn;
    private Spawner spawner;

    private void Awake()
    {
        spawner = GameObject.Find("Spawner").GetComponent<Spawner>();
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, radius);
    }

    private void Update()
    {
        Collider2D collider2D = Physics2D.OverlapCircle(transform.position, radius, whenToSpawn);
        if (collider2D && collider2D.gameObject.GetInstanceID() != spawnedOn.GetInstanceID())
        {
            //Debug.Log(collider2D.name);
            spawner.curScore += scoreForPeg;
            for (int i = 0; i < numOfSpawns; i++)
            {
                GameObject toSpawn = spawn[Random.Range(0, spawn.Count)];
                GameObject g = Instantiate(toSpawn, transform.position, transform.rotation);
                g.GetComponent<SpawnOnBounce>().spawnedOn = collider2D.gameObject;
                g.GetComponent<Rigidbody2D>().velocity = GetComponent<Rigidbody2D>().velocity;
            }
            spawnedOn = collider2D.gameObject;
            if(destroy)
            {
                Destroy(gameObject);
            }
        }
    }
}
